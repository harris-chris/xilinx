


#ifndef SKETCH_H_
#define SKETCH_H_

/***************************** Include Files *********************************/
#include <stdio.h>
#include <stdlib.h>
#include "core/arty.h"


/************************** Constant Definitions *****************************/



/************************** Function Prototypes ******************************/


void loop(void);
void setup(void);

#endif /* SKETCH_H_ */
